import random
import time
import os
import cmath

money = 100




#Write your game of chance functions here

#####                          #####     
#####                          #####
#####       Flip the coin      #####
#####                          #####
#####                          #####
def flip_coin():

    global money
    
    os.system('clear')
       
    time.sleep(0.5)

    print("""
                 ___ _ _        _   _           ___     _      
                | __| (_)_ __  | |_| |_  ___   / __|___(_)_ _  
                | _|| | | '_ \ |  _| ' \/ -_) | (__/ _ \ | ' \ 
                |_| |_|_| .__/  \__|_||_\___|  \___\___/_|_||_|
                        |_|                                    

     
    """)
    if(money > 0):
        print("                                          You have: " + str(money) + "$")
        time.sleep(0.5)
        print("""
                                    How much do you wanna bet?
                                        (0 = back to menu)
        """)
        
        amount = int(input())
        if(amount == 0):
            intro()
        else:
            while(amount > money):
                print("                      You cannot bet more money than you have. Try again")
                amount = int(input())
            time.sleep(2)
            print("""
                                      Heads(1) or Tails(2)?
            """)
            bet = int(input())
            while(bet != 1 and bet != 2):
                print("                           Wrong number. Choose [1-2]")
                bet = int(input())
            
            time.sleep(1)
            print("""
                                          Flipping coin
            """)
            coin = random.randint(1, 2)
            if(coin == 1):
                print(" ")
                print("                                             Heads")
                time.sleep(1)
            else:
                print(" ")
                print("                                             Tails")
                time.sleep(1)
            
            if(bet == coin):
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(1)
                money = money + amount
                
            else:
                print(" ")
                print("                                          you lost: " + str(amount) + "$")
                time.sleep(1)
                money = money - amount
                
            time.sleep(1.2)
            flip_coin()
    else:
        print("                                You have no money left")
        time.sleep(1)
        game_over()


#####                          #####     
#####                          #####
#####         Cho  Han         #####
#####                          #####
#####                          #####

def cho_han():
    global money
    time.sleep(1)
    os.system('clear')
       
    time.sleep(0.5)

    print("""
                                  ___ _             _  _           
                                 / __| |_  ___     | || |__ _ _ _  
                                | (__| ' \/ _ \    | __ / _` | ' \ 
                                 \___|_||_\___/    |_||_\__,_|_||_|

     
    """)
    if(money > 0):
        print("                                          You have: " + str(money) + "$")
        time.sleep(0.5)
        print("""
                                    How much do you wanna bet?
                                        (0 = back to menu)
        """)
        
        amount = int(input())
        if(amount == 0):
            intro()
        else:
            while(amount > money):
                print("                      You cannot bet more money than you have. Try again")
                amount = int(input())
            time.sleep(2)
            print("""                       
                                      Please Make a Choice:
                                      ---------------------

                                          1. Cho (Even)
                                          2. Han (Odd)
            """)
            bet = int(input())
            while(bet != 1 and bet != 2):
                print("                           Wrong number. Choose [1-2]")
                bet = int(input())
            
            time.sleep(1)
            print("""
                                          Throwing Dices
            """)
            dice1 = random.randint(1, 6)
            dice2 = random.randint(1, 6)
            
            if(dice1 + dice2 % 2 == 0):
                print(" ")
                print("                                             Cho (Even)")
                time.sleep(1)
                if(bet == 1):
                    print(" ")
                    print("                                          you won: " + str(amount) + "$")
                    time.sleep(1)
                    money = money + amount
                else:
                    print(" ")
                    print("                                          you lost: " + str(amount) + "$")
                    time.sleep(1)
                    money = money - amount
            else:
                print(" ")
                print("                                             Han (Odd)")
                time.sleep(1)
                if(bet == 2):
                    print(" ")
                    print("                                          you won: " + str(amount) + "$")
                    time.sleep(1)
                    money = money + amount
                else:
                    print(" ")
                    print("                                          you lost: " + str(amount) + "$")
                    time.sleep(1)
                    money = money - amount
                         
            time.sleep(1.2)
            cho_han()
    else:
        print("                                     You have no money left")
        time.sleep(1)
        game_over()



#####                          #####     
#####                          #####
#####       Cards Battle       #####
#####                          #####
#####                          #####
    

def cards_battle():
    global money
    time.sleep(1)
    os.system('clear')
       
    time.sleep(0.5)

    cards = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
    figure = ["Spades", "Hearts", "Diamonds", "Clubs"]

    print("""
                             ___             _      ___       _   _   _     
                            / __|__ _ _ _ __| |___ | _ ) __ _| |_| |_| |___ 
                           | (__/ _` | '_/ _` (_-< | _ \/ _` |  _|  _| / -_)
                            \___\__,_|_| \__,_/__/ |___/\__,_|\__|\__|_\___|
                                                              _
                                      ,'`.    _  _    /\    _(_)_
                                     (_,._)  ( `' )  <  >  (_)+(_)
                                       /\     `.,'    \/      |
     
    """)
    if(money > 0):
        print("                                            You have: " + str(money) + "$")
        time.sleep(0.5)
        print("""
                                      How much do you wanna bet?
                                          (0 = back to menu)
        """)
        
        amount = int(input())
        if(amount == 0):
            intro()
        else:
            while(amount > money):
                print("                      You cannot bet more money than you have. Try again")
                amount = int(input())
            time.sleep(2)
            print("""                       
                              Press enter to pick a card from the stack:
                              ------------------------------------------                        
            """)
            input()
            
            time.sleep(1)
            print("""
                                           Picking card...
            """)
            time.sleep(1)
            user_rand_card = random.randint(0, 12)
            user_rand_figure = random.randint(0, 3)

            user_card = cards[user_rand_card] + " of " + figure[user_rand_figure]
            
            comp_rand_card = random.randint(0, 12)
            comp_rand_figure = random.randint(0, 3)
            
            comp_card = cards[comp_rand_card] + " of " + figure[comp_rand_figure]

            while(user_card == comp_card):
                comp_rand_card = random.randint(0, 12)
                comp_rand_figure = random.randint(0, 3)
            
                comp_card = cards[comp_rand_card] + " of " + figure[comp_rand_figure]
            

            print("""
                                      User card: {user_card}
                                      Comp card: {comp_card}
            """.format(user_card = user_card, comp_card = comp_card))
            time.sleep(1)
            
            if(user_rand_card == comp_rand_card):
                print(" ")
                print("                                             This is a draw")
                time.sleep(1)
            
            elif(user_rand_card > comp_rand_card):
                    print(" ")
                    print("                                          you won: " + str(amount) + "$")
                    time.sleep(2)
                    money = money + amount
            elif(user_rand_card < comp_rand_card):
                    print(" ")
                    print("                                          you lost: " + str(amount) + "$")
                    time.sleep(2)
                    money = money - amount
            
                         
            time.sleep(1.2)
            cards_battle()
    else:
        print("                                     You have no money left")
        time.sleep(1)
        game_over()


#####                          #####     
#####                          #####
#####       Roulette           #####
#####                          #####
#####                          #####

def roulette():
    global money
    time.sleep(1)
    os.system('clear')
       
    time.sleep(0.5)


    print("""
                                   ___          _     _   _       
                                  | _ \___ _  _| |___| |_| |_ ___ 
                                  |   / _ \ || | / -_)  _|  _/ -_)
                                  |_|_\___/\_,_|_\___|\__|\__\___|

     
    """)
    if(money > 0):
        print("                                            You have: " + str(money) + "$")
        time.sleep(0.5)
        print("""
                                      How much do you wanna bet?
                                          (0 = back to menu)
        """)
        
        amount = int(input())
        if(amount == 0):
            intro()
        else:
            while(amount > money):
                print("                      You cannot bet more money than you have. Try again")
                amount = int(input())
            time.sleep(2)
            print("""                       
                                 Choose what do you wanna bet for:
                                 ---------------------------------
                                       1. High or Low
                                       2. Red or Black
                                       3. Odd or Even                       
                                       4. Single Number

                                       5. Back to Menu
            """)
            
        bet_game = int(input())
        # We check the input is a number between 1 and 5    
        while(bet_game < 1 or bet_game > 5):
            print(" ")
            print("You need a number between [1-5]")
            bet_game = int(input())

        if(bet_game == 5):
            intro()
        if(bet_game == 1):
            print(" ")
            print("                                   Betting for High or Low")
            print("""     
                                        1. Low [1-18]
                                        2. High [19-36]
        """)
            choice = int(input())
            while(choice != 1 and choice != 2):
                print(" ")
                print("                                             Choose a number between [1-2]")
                choice = int(input())
            number = random.randint(1, 36)
            if(number < 19 and choice == 1):
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(2)
                money = money + amount
            elif(number > 18 and choice == 2):
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(2)
                money = money + amount
            else:
                print(" ")
                print("                                          you lost: " + str(amount) + "$")
                time.sleep(2)
                money = money - amount
            roulette()
        if(bet_game == 2):
            print(" ")
            print("                                   Betting for Red or Black")
            print("""     
                                            1. Red
                                            2. Black
            """)
            choice = int(input())
            while(choice != 1 and choice != 2):
                print(" ")
                print("                                             Choose a number between [1-2]")
                choice = int(input())
            number = random.randint(1, 36)
            if(number == choice):
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(2)
                money = money + amount
            else:
                print(" ")
                print("                                          you lost: " + str(amount) + "$")
                time.sleep(2)
                money = money - amount
            roulette()
        if(bet_game == 3):
            print(" ")
            print("                                   Betting for Odd or Even")
            print("""     
                                            1. Odd
                                            2. Even
            """)
            choice = int(input())
            while(choice != 1 and choice != 2):
                print(" ")
                print("                                             Choose a number between [1-2]")
                choice = int(input())
            number = random.randint(1, 36)
            if(number == choice):
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(2)
                money = money + amount
            else:
                print(" ")
                print("                                          you lost: " + str(amount) + "$")
                time.sleep(2)
                money = money - amount
            roulette()
        if(bet_game == 4):
            print(" ")
            print("                                   Betting for Single Number")
            print("                                     Enter a number [1-36]")
            choice = int(input())
            while(choice < 1 or choice > 36):
                print(" ")
                print("                                             Choose a number between [1-36]")
                choice = int(input())
            number = random.randint(1, 36)
            if(number == choice):
                amount = amount * 3
                print(" ")
                print("                                          you won: " + str(amount) + "$")
                time.sleep(2)
                money = money + amount
            else:
                print(" ")
                print("                                          you lost: " + str(amount) + "$")
                time.sleep(2)
                money = money - amount
            roulette()
    else:
        print("                                     You have no money left")
        time.sleep(1)
        game_over()

def game_over():
    print(" ")
    print("                                       End of Game")
    print(" ")
    exit

def intro():
    time.sleep(0.5)
    os.system('clear')
    time.sleep(1)
    print("""
                                 _   _   _   _   _   _   _     _   _  
                                / \ / \ / \ / \ / \ / \ / \   / \ / \ 
                               ( W | e | l | c | o | m | e ) ( T | o )
                                \_/ \_/ \_/ \_/ \_/ \_/ \_/   \_/ \_/ 

                    
    """)
    time.sleep(1)
    os.system('clear')
    time.sleep(0.5)
    print("""



                ___      __  __     ___    ___   __    ___ _      _        ___     
               / __|__ _|  \/  |___/ __|  / _ \ / _|  / __| |_   /_\  _ _ / __|___ 
              | (_ / _` | |\/| / -_)__ \ | (_) |  _| | (__| ' \ / _ \| ' \ (__/ -_)
               \___\__,_|_|  |_\___|___/  \___/|_|    \___|_||_/_/ \_\_||_\___\___|

    """)
    time.sleep(1)
    print("""
                                What game do you want to play?

                                    1. flip the coin
                                    2. cho-han
                                    3. cards battle
                                    4. roulette

                                    5. exit
    """)
    
    game = int(input())
    # We check the input is a number between 1 and 5    
    while(game < 1 or game > 5):
        print(" ")
        print("You need a number between [1-5]")
        game = int(input())

    if(game == 5):
        game_over()
    if(game == 1):
        flip_coin()
    if(game == 2):
        cho_han()
    if(game == 3):
        cards_battle()
    if(game == 4):
        roulette()

#Call your game of chance functions here
intro()


